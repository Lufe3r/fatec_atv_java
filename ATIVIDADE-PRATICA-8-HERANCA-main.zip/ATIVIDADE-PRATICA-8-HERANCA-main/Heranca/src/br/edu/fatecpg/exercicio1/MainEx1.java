package br.edu.fatecpg.exercicio1;

public class MainEx1 {

	public static void main(String[] args) {
		Gerente gerente = new Gerente();
		Vendedor vendedor = new Vendedor();
		Faxineiro faxineiro = new Faxineiro();
		
		gerente.baterPonto();
		vendedor.baterPonto();
		faxineiro.baterPonto();
		
		gerente.fecharCaixa();
		vendedor.fecharCaixa();
		faxineiro.fecharCaixa();
		
		gerente.realizarVenda();
		vendedor.realizarVenda();
		faxineiro.realizarVenda();
		
		gerente.solicitarMaterial();;
		vendedor.solicitarMaterial();
		faxineiro.solicitarMaterial();
	}

}
