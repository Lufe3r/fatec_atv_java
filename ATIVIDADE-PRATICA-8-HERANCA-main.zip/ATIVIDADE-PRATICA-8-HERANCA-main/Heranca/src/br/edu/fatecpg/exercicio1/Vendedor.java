package br.edu.fatecpg.exercicio1;

public class Vendedor implements iFuncionario {
	public void baterPonto() {
		System.out.println("Ponto batido com sucesso!");
	}
	
	public void fecharCaixa() {
		System.out.println("Caixa fechado com sucesso");
	}
	
	public void realizarVenda() {
		System.out.println("Venda realizada com sucesso!");
	}
	
	public void solicitarMaterial() {
		System.out.println("Vendedor não solicita material");
	}
}
