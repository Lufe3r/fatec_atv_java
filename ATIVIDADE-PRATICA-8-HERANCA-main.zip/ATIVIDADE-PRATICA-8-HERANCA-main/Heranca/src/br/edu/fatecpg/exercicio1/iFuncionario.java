package br.edu.fatecpg.exercicio1;

public interface iFuncionario {
	public void baterPonto();
	public void fecharCaixa();
	public void realizarVenda();
	public void solicitarMaterial();
}
