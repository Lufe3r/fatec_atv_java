package br.edu.fatecpg.exercico2;

public class Calculadora implements iOperacaoMatematica{
	
	public void soma(double a, double b) {
		System.out.println("Resultado da soma: " + a+b);
	}
	
	public void subtracao(double a, double b) {
		System.out.println("Resultado da subtração: " + (a-b));
	}
	
	public void multiplicacao(double a, double b) {
		System.out.println("Resultado da multilicação: " + (a*b));
	}
	

	public void divisao(double a, double b) {
		System.out.println("Resultado da divisão: " + (a/b));
	}
}
