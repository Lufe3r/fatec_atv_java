package br.edu.fatecpg.exercico2;

public class MainEx2 {

	public static void main(String[] args) {
		Calculadora calc = new Calculadora();
		
		calc.soma(75.6, 50.7);
		calc.subtracao(50.5, 45.5);
		calc.multiplicacao(16.35, 17.21);
		calc.divisao(234.54, 130.75);
		
		
	}

}
