package br.edu.fatecpg.exercico2;

public interface iOperacaoMatematica {
	public void soma(double a, double b);
	public void subtracao(double a, double b);
	public void multiplicacao(double a, double b);
	public void divisao(double a, double b);
}
