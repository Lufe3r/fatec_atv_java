package br.edu.fatecpg.exercico3;

public class MainEx3 {

	public static void main(String[] args) {
		double valor = 100.00;

        PagamentoCartao pagamentoCartao = new PagamentoCartao(valor);
        PagamentoDinheiro pagamentoDinheiro = new PagamentoDinheiro(valor);

        System.out.println(pagamentoCartao.emitirRecibo());
        System.out.println("-------------------------------");
        System.out.println(pagamentoDinheiro.emitirRecibo());

	}

}
