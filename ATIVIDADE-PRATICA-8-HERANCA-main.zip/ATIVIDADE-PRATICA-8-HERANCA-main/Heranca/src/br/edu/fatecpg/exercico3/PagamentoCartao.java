package br.edu.fatecpg.exercico3;

public class PagamentoCartao implements iPagamento {
	
    private double valorBase;

    public PagamentoCartao(double valorBase) {
        this.valorBase = valorBase;
    }

    @Override
    public double calcularPagamento() {
        return valorBase * 1.05; // Acrescenta 5% de taxa
    }

    @Override
    public String emitirRecibo() {
        return String.format(
            "Recibo - Pagamento com Cartão\nValor base: R$ %.2f\nTaxa (5%%): R$ %.2f\nValor final: R$ %.2f\n",
            valorBase,
            valorBase * 0.05,
            calcularPagamento()
        );
    }

}
