package br.edu.fatecpg.exercico3;

public class PagamentoDinheiro implements iPagamento{
	private double valorBase;

    public PagamentoDinheiro(double valorBase) {
        this.valorBase = valorBase;
    }

    @Override
    public double calcularPagamento() {
        return valorBase * 0.90; // Aplica 10% de desconto
    }

    @Override
    public String emitirRecibo() {
        return String.format(
            "Recibo - Pagamento em Dinheiro\nValor base: R$ %.2f\nDesconto (10%%): R$ %.2f\nValor final: R$ %.2f\n",
            valorBase,
            valorBase * 0.10,
            calcularPagamento()
        );
    }
}
