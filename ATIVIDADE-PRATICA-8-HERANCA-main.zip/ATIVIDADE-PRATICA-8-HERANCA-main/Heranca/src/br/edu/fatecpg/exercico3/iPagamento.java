package br.edu.fatecpg.exercico3;

public interface iPagamento {
	public double calcularPagamento();
	public String emitirRecibo();
}
