package br.edu.fatecpg.exercico4;

import java.util.Scanner;

public class MainEx4 {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
	        SistemaDeSeguranca sistema = new SistemaDeSeguranca();

	        // Loop de login até acertar
	        while (!sistema.isAutenticado()) {
	            System.out.print("Usuário: ");
	            String usuario = scanner.nextLine();

	            System.out.print("Senha: ");
	            String senha = scanner.nextLine();

	            sistema.login(usuario, senha);
	        }

	        // Menu após login
	        int opcao;
	        do {
	            System.out.println("\n=== MENU ===");
	            System.out.println("1 - Ver status de autenticação");
	            System.out.println("2 - Logout");
	            System.out.println("3 - Sair");
	            System.out.print("Escolha uma opção: ");
	            opcao = scanner.nextInt();
	            scanner.nextLine(); // limpar quebra de linha

	            switch (opcao) {
	                case 1:
	                    if (sistema.isAutenticado()) {
	                        System.out.println("Usuário autenticado.");
	                    } else {
	                        System.out.println("Usuário não está autenticado.");
	                    }
	                    break;
	                case 2:
	                    sistema.logout();
	                    break;
	                case 3:
	                    System.out.println("Encerrando o sistema.");
	                    break;
	                default:
	                    System.out.println("Opção inválida.");
	            }

	        } while (opcao != 3);
	}

}
