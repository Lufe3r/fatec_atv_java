package br.edu.fatecpg.exercico4;

public class SistemaDeSeguranca implements iAutenticavel{
	
	 private final String usuarioCorreto = "admin";
	    private final String senhaCorreta = "1234";
	    private boolean autenticado = false;

	    @Override
	    public void login(String usuario, String senha) {
	        if (usuario.equals(usuarioCorreto) && senha.equals(senhaCorreta)) {
	            autenticado = true;
	            System.out.println("Login realizado com sucesso! Bem-vindo, " + usuario + "!");
	        } else {
	            System.out.println("Usuário ou senha incorretos. Tente novamente.\n");
	        }
	    }

	    @Override
	    public void logout() {
	        if (autenticado) {
	            autenticado = false;
	            System.out.println("Logout realizado com sucesso.");
	        } else {
	            System.out.println("Nenhum usuário está autenticado.");
	        }
	    }

	    public boolean isAutenticado() {
	        return autenticado;
	    }
}
