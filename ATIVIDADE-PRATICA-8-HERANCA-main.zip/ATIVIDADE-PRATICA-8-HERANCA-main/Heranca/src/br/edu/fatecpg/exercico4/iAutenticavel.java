package br.edu.fatecpg.exercico4;

public interface iAutenticavel {
	public void login(String usuario, String senha);

	public void logout();
}
